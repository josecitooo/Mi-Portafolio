
import React from 'react';
import { Github, Linkedin, Twitter } from 'lucide-react';

const socialMediaLinks = [
  {
    name: 'LinkedIn',
    icon: <Linkedin className="w-5 h-5" />,
    url: '#', 
  },
  {
    name: 'GitHub',
    icon: <Github className="w-5 h-5" />,
    url: '#',
  },
  {
    name: 'Twitter',
    icon: <Twitter className="w-5 h-5" />,
    url: '#',
  },
];

const SocialLinks = () => {
  return (
    <div className="flex gap-4">
      {socialMediaLinks.map((social) => (
        <a 
          key={social.name}
          href={social.url} 
          className="p-3 bg-gray-100 rounded-full hover:bg-blue-50 hover:text-blue-600 transition-all"
          aria-label={social.name}
          target="_blank"
          rel="noopener noreferrer"
        >
          {social.icon}
        </a>
      ))}
    </div>
  );
};

export default SocialLinks;
